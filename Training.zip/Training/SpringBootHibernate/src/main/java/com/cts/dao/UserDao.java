package com.cts.dao;

import com.cts.domain.UserDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * The interface User dao.
 */
@Repository
public interface UserDao extends JpaRepository<UserDTO, Long> {
}
