package com.cts.domain;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * The type User.
 */
public class User implements Serializable {

    /**
     * The User id.
     */
    private Long userId;

    /**
     * The First name.
     */
    @Size(max = 20, min = 3, message = "{user.firstName.invalid}")
    @NotBlank(message = "Please Enter your first name")
    private String firstName;

    /**
     * The Last name.
     */
    @Size(max = 20, min = 3, message = "{user.lastName.invalid}")
    @NotBlank(message = "Please Enter your last name")
    private String lastName;

    /**
     * The Email.
     */
    @Email(message = "{user.email.invalid}")
    @NotBlank(message = "Please Enter your email")
    private String email;

    /**
     * Instantiates a new User.
     */
    public User() {
        super();
    }

    /**
     * Instantiates a new User.
     *
     * @param userDTO the user dto
     */
    public User(final UserDTO userDTO) {
        this.userId = userDTO.getUserId();
        this.firstName = userDTO.getFullName().getFirstName();
        this.lastName = userDTO.getFullName().getLastName();
        this.email = userDTO.getEmail();
    }

    /**
     * Gets user Id.
     *
     * @return the user Id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * Sets user Id.
     *
     * @param userId the user Id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * Gets firstName.
     *
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets firstName.
     *
     * @param firstName the firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets last name.
     *
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets last name.
     *
     * @param lastName the last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets email.
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets email.
     *
     * @param email the email
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
