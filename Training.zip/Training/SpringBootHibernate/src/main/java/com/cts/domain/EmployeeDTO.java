package com.cts.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * The type Employee dto.
 */
@Entity
@Table(name = "TBL_EMPLOYEE")
public class EmployeeDTO implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "EMPLOYEE_ID", nullable = false)
    private int employeeId;

    @Column(name = "SALARY", unique = true)
    private int salary;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "street",
                    column = @Column(name="ADDRESS_LINE1")),
            @AttributeOverride(name = "area",
                    column = @Column(name="ADDRESS_LINE2"))
    })
    private Address address;

    @Embedded
    private Name employeeName = new Name();

    /**
     * Instantiates a new Employee dto.
     */
    public EmployeeDTO() {
        super();
    }

    /**
     * Instantiates a new Employee dto.
     *
     * @param employee the employee
     */
    public EmployeeDTO(final Employee employee) {
        this.address = new Address();
        this.address.setArea(employee.getAddressLine1());
        this.address.setStreet(employee.getAddressLine2());
        this.salary = employee.getSalary();
        this.employeeName.setFirstName(employee.getFirstName());
        this.employeeName.setLastName(employee.getLastName());
    }

    /**
     * Gets employee id.
     *
     * @return the employee id
     */
    public int getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets employee id.
     *
     * @param employeeId the employee id
     */
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    /**
     * Gets salary.
     *
     * @return the salary
     */
    public int getSalary() {
        return salary;
    }

    /**
     * Sets salary.
     *
     * @param salary the salary
     */
    public void setSalary(int salary) {
        this.salary = salary;
    }

    /**
     * Gets address.
     *
     * @return the address
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets address.
     *
     * @param address the address
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /**
     * Gets employee name.
     *
     * @return the employee name
     */
    public Name getEmployeeName() {
        return employeeName;
    }

    /**
     * Sets employee name.
     *
     * @param employeeName the employee name
     */
    public void setEmployeeName(Name employeeName) {
        this.employeeName = employeeName;
    }
}
