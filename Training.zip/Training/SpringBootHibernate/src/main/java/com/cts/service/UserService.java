package com.cts.service;

import com.cts.domain.User;

import java.util.List;

/**
 * The interface User service.
 */
public interface UserService {
    /**
     * Save.
     *
     * @param user the user
     */
    void save(User user);

    /**
     * List list.
     *
     * @return the list
     */
    List<User> list();
}
