package com.cts.service;

import com.cts.domain.Employee;

import java.util.List;

/**
 * The interface Employee service.
 */
public interface EmployeeService {
    /**
     * Save.
     *
     * @param employee the employee
     */
    void save(Employee employee);

    /**
     * Get employee employee.
     *
     * @param employeeId the employee id
     * @return the employee
     */
    Employee getEmployee(int employeeId);

    /**
     * List list.
     *
     * @return the list
     */
    List<Employee> list();
}
