package com.cts.domain;

import javax.persistence.Embeddable;

/**
 * The type Address.
 */
@Embeddable
class Address {
    /**
     * The Street.
     */
    private String street;

    /**
     * The Area.
     */
    private String area;

    /**
     * Gets street.
     *
     * @return the street
     */
    public String getStreet() {
        return street;
    }

    /**
     * Sets street.
     *
     * @param street the street
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     * Gets area.
     *
     * @return the area
     */
    public String getArea() {
        return area;
    }

    /**
     * Sets area.
     *
     * @param area the area
     */
    public void setArea(String area) {
        this.area = area;
    }

    @Override
    public String toString() {
        return area + " " + street;
    }
}