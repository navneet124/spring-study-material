package com.cts.controller;

import com.cts.domain.Employee;
import com.cts.service.EmployeeService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.Locale;

/**
 * The type Employee controller.
 */
@Api
@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

    /**
     * Employee form string.
     *
     * @param locale the locale
     * @param model  the model
     * @return the string
     */
    @GetMapping("/employees")
	public String employeeForm(Locale locale, Model model) {
		model.addAttribute("employees", employeeService.list());
		return "editEmployees";
	}

    /**
     * Form backing object employee.
     *
     * @return the employee
     */
    @ModelAttribute("employee")
	public Employee formBackingObject() {
		return new Employee();
	}

    /**
     * Save user string.
     *
     * @param employee the employee
     * @param result   the result
     * @param model    the model
     * @return the string
     */
    @PostMapping("/addEmployee")
	public String saveUser(@ModelAttribute("employee") @Valid Employee employee, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("employees", employeeService.list());
			return "editEmployees";
		}

		employeeService.save(employee);
		return "redirect:/employees";
	}

	/**
	 * Employee form string.
	 *
	 * @param locale the locale
	 * @param model  the model
	 * @return the string
	 */
	@GetMapping("/searchEmployee")
	public String searchEmployee(Locale locale, Model model) {
		return "searchEmployee";
	}
}
