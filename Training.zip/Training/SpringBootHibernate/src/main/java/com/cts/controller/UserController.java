package com.cts.controller;

import com.cts.domain.User;
import com.cts.service.UserService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.Locale;

/**
 * The type User controller.
 */
@Api
@Controller
public class UserController {

	@Autowired
	private UserService userService;

    /**
     * User form string.
     *
     * @param locale the locale
     * @param model  the model
     * @return the string
     */
    @GetMapping("/")
	public String userForm(Locale locale, Model model) {
		model.addAttribute("users", userService.list());
		return "editUsers";
	}

    /**
     * Form backing object user.
     *
     * @return the user
     */
    @ModelAttribute("user")
	public User formBackingObject() {
		return new User();
	}

    /**
     * Save user string.
     *
     * @param user   the user
     * @param result the result
     * @param model  the model
     * @return the string
     */
    @PostMapping("/addUser")
	public String saveUser(@ModelAttribute("user") @Valid User user, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("users", userService.list());
			return "editUsers";
		}

		userService.save(user);
		return "redirect:/";
	}
}
