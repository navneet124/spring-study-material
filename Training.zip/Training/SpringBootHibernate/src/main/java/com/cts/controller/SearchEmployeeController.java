package com.cts.controller;

import com.cts.domain.Employee;
import com.cts.service.EmployeeService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * The type Search employee controller.
 */
@Api
@RestController
public class SearchEmployeeController {

    /**
     * The Employee service.
     */
    @Autowired
    private EmployeeService employeeService;

    /**
     * Search employee response entity.
     *
     * @param employeeId the employee id
     * @return the response entity
     */
    @GetMapping("/cts/api/search")
    public ResponseEntity<Employee> searchEmployee(@RequestParam(value="employeeId", defaultValue = "1") int employeeId) {
        ResponseEntity<Employee> employeeResp;
        Employee employee = employeeService.getEmployee(employeeId);
        if (employee == null)  {
            employeeResp = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
            employeeResp = new ResponseEntity<>(employee, HttpStatus.OK);
        }
        return employeeResp;
    }
}
