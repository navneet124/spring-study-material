package com.cts.service;

import java.util.List;

import com.cts.domain.User;

/**
 * The interface User service.
 */
public interface UserService {
    /**
     * Save.
     *
     * @param user the user
     */
    void save(User user);

    /**
     * List list.
     *
     * @return the list
     */
    List<User> list();
}
