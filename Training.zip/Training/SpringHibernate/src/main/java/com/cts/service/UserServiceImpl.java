package com.cts.service;

import java.util.ArrayList;
import java.util.List;

import com.cts.domain.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.dao.UserDao;
import com.cts.domain.User;

/**
 * The type User service.
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Transactional
	public void save(User user) {
		final UserDTO userDTO = new UserDTO(user);
		userDao.save(userDTO);
	}

	@Transactional(readOnly = true)
	public List<User> list() {
		final List<User> userList = new ArrayList<>();
		final List<UserDTO> users = userDao.list();
		for (UserDTO userDTO : users) {
			userList.add(new User(userDTO));
		}
		return userList;
	}
}
