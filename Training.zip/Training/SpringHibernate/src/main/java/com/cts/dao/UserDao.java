package com.cts.dao;

import java.util.List;

import com.cts.domain.UserDTO;

/**
 * The interface User dao.
 */
public interface UserDao {
    /**
     * Save.
     *
     * @param user the user
     */
    void save(UserDTO user);

    /**
     * List list.
     *
     * @return the list
     */
    List<UserDTO> list();
}
