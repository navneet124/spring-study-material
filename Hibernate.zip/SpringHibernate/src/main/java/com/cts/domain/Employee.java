package com.cts.domain;

/**
 * The type Employee.
 */
public class Employee {

    private int employeeId;

    private String firstName;

    private String lastName;

    private int salary;

    private String addressLine1;

    private String addressLine2;

    /**
     * Instantiates a new Employee.
     */
    public Employee() {
        super();
    }

    /**
     * Instantiates a new Employee.
     *
     * @param employeeDTO the employee dto
     */
    public Employee(final EmployeeDTO employeeDTO) {
        this.employeeId = employeeDTO.getEmployeeId();
        this.firstName = employeeDTO.getEmployeeName().getFirstName();
        this.lastName = employeeDTO.getEmployeeName().getLastName();
        this.addressLine1 = employeeDTO.getAddress().getArea();
        this.addressLine2 = employeeDTO.getAddress().getStreet();
    }

    /**
     * Gets employee id.
     *
     * @return the employee id
     */
    public int getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets employee id.
     *
     * @param employeeId the employee id
     */
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    /**
     * Gets first name.
     *
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets first name.
     *
     * @param firstName the first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets last name.
     *
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets last name.
     *
     * @param lastName the last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets salary.
     *
     * @return the salary
     */
    public int getSalary() {
        return salary;
    }

    /**
     * Sets salary.
     *
     * @param salary the salary
     */
    public void setSalary(int salary) {
        this.salary = salary;
    }

    /**
     * Gets address line 1.
     *
     * @return the address line 1
     */
    public String getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets address line 1.
     *
     * @param addressLine1 the address line 1
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    /**
     * Gets address line 2.
     *
     * @return the address line 2
     */
    public String getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets address line 2.
     *
     * @param addressLine2 the address line 2
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
}
