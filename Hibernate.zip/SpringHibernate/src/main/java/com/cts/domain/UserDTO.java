package com.cts.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * The type User dto.
 */
@Entity
@Table(name = "TBL_USERS")
public class UserDTO implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "USER_ID", nullable = false)
    private Long userId;

    @Embedded
    private Name fullName;

    @Column(name = "USER_EMAIL", unique = true)
    private String email;

    /**
     * Instantiates a new User dto.
     */
    public UserDTO() {
        super();
    }

    /**
     * Instantiates a new User dto.
     *
     * @param user the user
     */
    public UserDTO(final User user) {
        this.userId = user.getUserId();
        this.fullName = new Name();
        this.fullName.setFirstName(user.getFirstName());
        this.fullName.setLastName(user.getLastName());
        this.email = user.getEmail();
    }

    /**
     * Gets user Id.
     *
     * @return the user Id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * Sets user Id.
     *
     * @param userId the user Id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * Gets fullName.
     *
     * @return the fullName
     */
    public Name getFullName() {
        return fullName;
    }

    /**
     * Sets fullName.
     *
     * @param fullName the fullName
     */
    public void setFullName(Name fullName) {
        this.fullName = fullName;
    }

    /**
     * Gets email.
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets email.
     *
     * @param email the email
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
