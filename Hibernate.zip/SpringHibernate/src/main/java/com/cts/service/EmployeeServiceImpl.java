package com.cts.service;

import com.cts.dao.EmployeeDao;
import com.cts.domain.Employee;
import com.cts.domain.EmployeeDTO;
import com.cts.domain.User;
import com.cts.domain.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Employee service.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Transactional
	public void save(Employee employee) {
		final EmployeeDTO employeeDTO = new EmployeeDTO(employee);
		employeeDao.save(employeeDTO);
	}

	@Transactional(readOnly = true)
	public List<Employee> list() {
		final List<Employee> employeeList = new ArrayList<>();
		final List<EmployeeDTO> employees = employeeDao.list();
		for (EmployeeDTO employeeDTO : employees) {
			employeeList.add(new Employee(employeeDTO));
		}
		return employeeList;
	}
}
