package com.cts.service;

import com.cts.domain.Employee;

import java.util.List;

/**
 * The interface Employee service.
 */
public interface EmployeeService {
    /**
     * Save.
     *
     * @param employee the employee
     */
    void save(Employee employee);

    /**
     * List list.
     *
     * @return the list
     */
    List<Employee> list();
}
