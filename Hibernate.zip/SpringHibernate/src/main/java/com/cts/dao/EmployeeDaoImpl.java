package com.cts.dao;

import com.cts.domain.EmployeeDTO;
import com.cts.domain.UserDTO;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.util.List;

/**
 * The type Employee dao.
 */
@Repository
public class EmployeeDaoImpl implements EmployeeDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void save(EmployeeDTO employee) {
        sessionFactory.getCurrentSession().save(employee);
    }

    @Override
    public List<EmployeeDTO> list() {
        @SuppressWarnings("unchecked")
        TypedQuery<EmployeeDTO> query = sessionFactory.getCurrentSession().createQuery("from EmployeeDTO");
        return query.getResultList();
    }
}
