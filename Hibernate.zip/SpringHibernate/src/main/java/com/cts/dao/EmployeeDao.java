package com.cts.dao;

import com.cts.domain.EmployeeDTO;

import java.util.List;

/**
 * The interface Employee dao.
 */
public interface EmployeeDao {
    /**
     * Save.
     *
     * @param employee the employee
     */
    void save(EmployeeDTO employee);

    /**
     * List list.
     *
     * @return the list
     */
    List<EmployeeDTO> list();
}
